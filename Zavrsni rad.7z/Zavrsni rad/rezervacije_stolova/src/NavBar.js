import React from "react";
import { NavLink, Outlet } from "react-router-dom";

function NavBar() {
  return (
    <div>
      <div className="">
        <div className="moj-navbar d-flex align-items-center">
          <ul className="ms-4">
            <li>
              <NavLink
                to="/navbar/unosRezervacija"
                className={({ isActive }) => (isActive ? "active" : "navlink")}
              >
                Unos rezervacija
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/navbar/pregledRezervacija"
                className={({ isActive }) => (isActive ? "active" : "navlink")}
              >
                Rezervacije
              </NavLink>
            </li>
            <li>
              <NavLink to="/" className="navlink">
                Logout
              </NavLink>
            </li>
          </ul>
        </div>
      </div>
      <div>
        <Outlet />
      </div>
    </div>
  );
}

export default NavBar;

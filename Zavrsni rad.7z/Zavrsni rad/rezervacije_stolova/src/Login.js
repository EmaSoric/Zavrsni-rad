import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { CiUser } from "react-icons/ci";
import MessagesAlert from "./messages/MessagesAlert";

function Login() {
  const [alert, setAlert] = useState(null);
  const [showInput, setShowInput] = useState(false);
  const [values, setValues] = useState({
    username: "" /**nazivi state varijabli moraju biti isti kao i u mysql-u */,
    lozinka: "",
  });
  const [adminLozinka, setAdminLozinka] = useState(""); /**za admin lozinku */

  const navigate = useNavigate();
  //axios.defaults.withCredentials = true; /**to je za cookies */

  const handleSubmit = (e) => {
    /**event ili e se povlači iz forme */
    e.preventDefault();
    const { username, lozinka } = values;
    if (!username || !lozinka) {
      setAlert({
        poruka: "Molimo unesite korisničko ime i lozinku.",
        type: "info",
      });
      return;
    }

    axios
      .post(
        "http://localhost:5000/auth/korLogin",
        values
      ) /** stranica na koju će nas gumb prebaciti nakon prijave */
      .then((res) => {
        const { ime, id } =
          res.data; /**varijabla u koju ćemo spremiti podatke za prijavu kako bismo ispisali korisničko ime u unosu rezervacija */
        console.log(res); /**resultat */
        if (res.data.loginStatus) {
          console.log(
            "Login uspješan.preusmjeravam na unosRezervacija s korisničkim imenom:",
            ime
          );
          /**ako je login uspjesan preusmjeri korisnika na tu stranicu */
          navigate("/navbar", {
            state: {
              korIme: ime,
              korId: id,
            } /**ovdje smo ažurirali varijablu */,
          });
        } else {
          setAlert({ poruka: "Pogrešno korisničko ime ili lozinka!" });
        }
      })
      .catch((err) => console.log(err)); /**eventualna greška  */
  };

  const handleAdminLogin = () => {
    axios /**frontend šalje POST zahtjev backendu */
      .post(
        "http://localhost:5000/auth/login" /**backend ruta koju definiram u expressu */,
        {
          lozinka: adminLozinka,
        } /**lozinka u backendu očekuje vrijednost adminLozinka iz frontenda */
      ) /**podaci koje šaljem serveru */
      .then((result) => {
        /**then... tu čekam odgovor sa backenda koji ako je uspješan prebacuje me na /registracija */
        if (result.data.loginStatus) {
          navigate("/registracija");
        } else {
          console.log(result.data.Error);
          setAlert({ poruka: "Pogrešna lozinka!", type: "error" });
        }
      })
      .catch((err) => console.log(err));
  };

  const handleChange = (e) => {
    setValues({ ...values, [e.target.name]: e.target.value });
  };

  return (
    <div>
      <h2>
        <CiUser
          style={{ marginRight: "6px", fontSize: "25px" }}
          strokeWidth={2}
        />
        Prijava
      </h2>
      {alert && (
        <MessagesAlert
          poruka={alert.poruka}
          type={alert.type}
          onClose={() => setAlert(null)}
        />
      )}
      <form className="login-box" onSubmit={handleSubmit}>
        {
          //<div className="text-danger">{error && error}</div> /**ova linija koda nam ispisuje grešku na ekranu */
        }
        <div className="form">
          <label> Korisničko ime:</label>
          <input
            type="text"
            name="username"
            placeholder="korisničko ime"
            value={values.username}
            onChange={
              handleChange
            } /**...values znači da ćemo zadržati elemente iz objekta i samo dodati email u ovom slučaju, ažurirati ćemo objekt */
          ></input>
        </div>
        <div className="form">
          <label>Lozinka:</label>
          <input
            type="password"
            name="lozinka"
            placeholder="XXXX"
            maxLength={"4"}
            value={values.lozinka}
            onChange={
              handleChange
            } /**ovdje smo samo ažurirali lozinku u objektu */
          ></input>
        </div>
        <button className="btn">PRIJAVA</button>
      </form>
      <button className="btn-reg" onClick={() => setShowInput((show) => !show)}>
        Registriraj novog konobara
      </button>
      {showInput && (
        <div className="reg-passwordInput">
          <input
            className="regInput"
            type="password"
            placeholder="Unesite administracijsku lozinku"
            minLength={"8"}
            onChange={(e) => setAdminLozinka(e.target.value)}
          ></input>
          <button className="btn btn-outline-info" onClick={handleAdminLogin}>
            ✔
          </button>
        </div>
      )}
    </div>
  );
}

export default Login;

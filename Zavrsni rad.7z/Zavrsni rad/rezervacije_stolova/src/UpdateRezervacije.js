import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

function UpdateRezervacije() {
  const [updateRezValues, setUpdateRezValues] = useState({
    imeRezervacije: "",
    datum: "",
    vrijeme: "",
    brOsoba: "",
    posebnaNapomena: "",
    broj_stola: "",
    id_kor: "",
  });
  const [stolovi, setStolovi] = useState([]);
  const [konobari, setKonobari] = useState([]);
  const { id } = useParams();
  /**dohvaćanje elemenata za prikaz u rezervaciji */
  useEffect(() => {
    axios
      .get("http://localhost:5000/res/stolovi")
      .then((res) => {
        setStolovi(res.data);
      })
      .catch((err) => console.log(err));
    axios
      .get("http://localhost:5000/korisnici")
      .then((res) => {
        setKonobari(res.data);
      })
      .catch((err) => console.log(err));
  }, []);
  /**dohvaćanje ID rezervacije za ispis u formi */
  useEffect(() => {
    axios
      .get("http://localhost:5000/rezervacijaID/" + id)
      .then((res) => {
        console.log("Primljeni podaci: ", res.data);
        setUpdateRezValues({
          imeRezervacije: res.data.imeRezervacije,
          datum: res.data.datum,
          vrijeme: res.data.vrijeme,
          brOsoba: res.data.brOsoba,
          posebnaNapomena: res.data.posebnaNapomena,
          broj_stola: res.data.broj_stola,
          id_kor: res.data.id_kor,
        });
      })
      .catch((err) => console.log(err));
  }, [id]);

  const handleSubmit = (e) => {
    e.preventDefault();
  };
  const handleChange = (e) => {
    const { name, value } =
      e.target; /**ova linija koda dohvaća name i value vrijednosti iz inputa */

    setUpdateRezValues((prev) => ({
      /**azuriram updaterezValues tako da zadrzavam postojece vrijednosti prev */
      ...prev,
      [name]: ["brOsoba", "broj_stola", "id_kor"].includes(
        name
      ) /**ako je [name] jedno od navedenog onda.. */
        ? value ===
          "" /**ako je value prazan string pusti prazan string ineče parsiraj u integer.. */
          ? ""
          : parseInt(value)
        : value /**ili za druga polja ako je string text sačuvaj string kao što i je */,
    }));
  };
  return (
    <div>
      <form className="unosRez-box" onSubmit={handleSubmit}>
        <div>
          <label>Ime rezervacije:</label>
          <input
            type="text"
            name="imeRezervacije"
            value={updateRezValues.imeRezervacije}
            onChange={handleChange}
          ></input>
        </div>
        <div>
          <label>Datum rezervacije:</label>
          <input
            type="text"
            name="datum"
            value={updateRezValues.datum}
            onChange={handleChange}
            placeholder="npr. 10.05.2025."
          />
        </div>
        <div>
          <label>Vrijeme dolaska:</label>
          <input
            type="text"
            name="vrijeme"
            value={updateRezValues.vrijeme}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Broj osoba:</label>
          <input
            type="number"
            name="brOsoba"
            value={updateRezValues.brOsoba}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Posebne napomene:</label>
          <textarea
            rows="6"
            name="posebnaNapomena"
            value={updateRezValues.posebnaNapomena}
            onChange={handleChange}
            placeholder="Napomena"
          />
        </div>
        <div>
          <label>Odaberi stol:</label>
          <select
            name="broj_stola"
            value={updateRezValues.broj_stola}
            onChange={handleChange}
          >
            <option value="">Odaberi stol:</option>
            {stolovi.map((stol) => (
              <option key={stol.broj_stola} value={stol.broj_stola}>
                Stol {stol.broj_stola} (kapacitet: {stol.broj_mjesta})
              </option>
            ))}
          </select>
        </div>
        <div>
          <label>Odaberi konobara:</label>
          <select
            name="id_kor"
            value={updateRezValues.id_kor}
            onChange={handleChange}
          >
            <option value="">Odaberi konobara:</option>
            {konobari.map((kon) => (
              <option key={kon.id} value={kon.id}>
                Konobar:
                {kon.username}
              </option>
            ))}
          </select>
        </div>
        <button className="btn">Ažuriraj rezervaciju</button>
        <button className="btn-cancel">X</button>
      </form>
    </div>
  );
}

export default UpdateRezervacije;

import React, { useEffect } from "react";
import { useState } from "react";
import axios from "axios";
import { FaPen, FaTrash } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

function PregledRezervacija() {
  const [rezervacije, setRezervacije] = useState([]);
  const [traziPojam, setTraziPojam] = useState("");
  const navigate = useNavigate();
  /**Dohvačanje rezervacija: */
  useEffect(() => {
    axios
      .get("http://localhost:5000/res/prikazRezervacije")
      .then((res) => {
        setRezervacije(res.data);
      })
      .catch((err) => console.log(err));
  });
  /**ručno parsiranje datuma za sortiranje u tablici:
   * datumString.split(".")- razdvaja datum po točki
   * Prvu vrijednsot sprema u dan, drugu vrijednost u mjesec treću u godinu
   * padStart - dodaje pod mjesec 0 ako je upisan jednoznamenkasti broj
   *
   */
  const parseDatum = (datumString) => {
    const [dan, mjesec, godina] = datumString.split(".");
    return new Date(
      `${godina}-${mjesec.padStart(2, "0")}-${dan.padStart(2, "0")}`
    );
  };
  const filtriraneRezervacije = rezervacije
    .filter(
      (rez) =>
        rez.imeRezervacije.toLowerCase().includes(traziPojam.toLowerCase()) ||
        rez.datum.includes(traziPojam) ||
        rez.vrijeme.includes(traziPojam) ||
        rez.username.includes(traziPojam) ||
        String(rez.broj_stola).includes(traziPojam) ||
        String(rez.brOsoba).includes(traziPojam)
    )
    .sort((a, b) => parseDatum(b.datum) - parseDatum(a.datum));

  const handleDelete = (id) => {
    if (window.confirm(`Obriši rezervaciju "${id}"?`)) {
      axios
        .delete("http://localhost:5000/deleteRez/" + id)
        .then((res) => {
          setRezervacije(rezervacije.filter((rez) => rez.id !== id));
        })
        .catch((err) => console.log(err));
    }
  };
  return (
    <div>
      <h3>Rezervacije</h3>

      <div className="okvir-tablice">
        <input
          className="trazilica"
          placeholder="Unesite traženi pojam"
          value={traziPojam}
          onChange={(e) => setTraziPojam(e.target.value)}
        ></input>
        <table className="moja-tablica">
          <thead>
            <tr>
              <th>Datum:</th>
              <th>Ime rezervacije:</th>
              <th>Vrijeme rezervacije:</th>
              <th>Broj osoba:</th>
              <th>Posebna napomena:</th>
              <th>Stol broj:</th>
              <th>Konobar:</th>
              <th></th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filtriraneRezervacije.map((d, i) => (
              <tr key={i}>
                <td>{d.datum}</td>
                <td>{d.imeRezervacije}</td>
                <td>{d.vrijeme}</td>
                <td>{d.brOsoba}</td>
                <td>{d.posebnaNapomena}</td>
                <td>{d.broj_stola}</td>
                <td>{d.username}</td>
                <td>
                  <button
                    className="gumb gumb-uredi"
                    onClick={() => {
                      navigate(`/urediRezervaciju/${d.id}`);
                    }}
                  >
                    <FaPen style={{ marginRight: "6px" }} />
                    Uredi
                  </button>
                </td>
                <td>
                  <button
                    className="gumb-cancel"
                    onClick={(e) => handleDelete(d.id)}
                  >
                    <FaTrash style={{ marginRight: "6px" }} />
                    Obriši
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default PregledRezervacija;

import React, { useState, useEffect } from "react";
import axios from "axios";
import MessagesAlert from "./messages/MessagesAlert";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

function Registracija() {
  const [alert, setAlert] = useState(null);
  const [regValues, setRegValues] = useState({
    username: "",
    lozinka: "",
    imeKorisnika: "",
    prezimeKorisnika: "",
    kontaktBroj: "",
  });

  const [korisnici, setKorisnici] = useState([]);

  /**dohvačanje korisnika za prikaz u tablici i Spremimamo mi ih u state */
  useEffect(() => {
    axios
      .get("http://localhost:5000/korisnici")
      .then((res) => {
        setKorisnici(res.data);
      })
      .catch((err) => console.log(err));
  }, []);

  /** Slanje unesenih podataka o registraciji kroisnika */
  const handleSubmit = (e) => {
    e.preventDefault();
    const { username, lozinka, imeKorisnika, prezimeKorisnika } = regValues;
    const postojeciKorisnik = korisnici.some((k) => k.username === username);
    if (postojeciKorisnik) {
      setAlert({
        poruka: (
          <>
            Korisnik <strong> {username}</strong> već postoji."
          </>
        ),

        type: "error",
      });
      return;
    }
    if (!username || !lozinka || !imeKorisnika || !prezimeKorisnika) {
      setAlert({ poruka: "Potrebno je popuniti sva polja!", type: "error" });
    } else {
      axios
        .post("http://localhost:5000/auth/registracija", regValues)
        .then((result) => {
          console.log(result);

          if (result.data.regStatus) {
            axios
              .get("http://localhost:5000/korisnici")
              .then((res) => {
                setKorisnici(res.data);
                setAlert({
                  poruka: "Korisnik je uspiješno spremljen.",
                  type: "success",
                });
                setRegValues({
                  username: "",
                  lozinka: "",
                  imeKorisnika: "",
                  prezimeKorisnika: "",
                  kontaktBroj: "",
                });
              })

              .catch((err) => console.log(err));
          } else {
            console.log(result.data.Error);
            alert("Došlo je do greške. Pokušajte ponovo.");
          }
        })
        .catch((err) => {
          if (err.response && err.response.status === 409) {
            alert(err.response.data.Error);
          } else {
            setAlert({
              poruka: "Došlo je do greške prilikom spremanja podataka.",
              type: "info",
            });
          }
        });
    }
  };

  /**Brisanje korisnika u tablici */
  const handleDelete = (id, username) => {
    if (window.confirm(`Obriši korisnika "${username}"?`)) {
      axios
        .delete("http://localhost:5000/delete/" + id)
        .then((res) => {
          setKorisnici(korisnici.filter((kor) => kor.id !== id));
        })
        .catch((err) => console.log(err));
    }
  };
  const navigate = useNavigate();
  return (
    <div>
      <h2>Registracija konobara</h2>
      {alert && (
        <MessagesAlert
          poruka={alert.poruka}
          type={alert.type}
          onClose={() => setAlert(null)}
        />
      )}

      <form className="reg-box" onSubmit={handleSubmit}>
        <div className="form">
          <label>Korisničko ime konobara:</label>
          <input
            type="text"
            name="username"
            onChange={(e) =>
              setRegValues({ ...regValues, username: e.target.value })
            }
            placeholder="Kreirajte korisničko ime"
          ></input>
        </div>
        <div className="form">
          <label>Lozinka:</label>
          <input
            type="password"
            name="lozinka"
            maxLength={4}
            onChange={(e) =>
              setRegValues({ ...regValues, lozinka: e.target.value })
            }
            placeholder="xxxx"
          ></input>
        </div>
        <div className="form">
          <label>Ime konobara:</label>
          <input
            type="text"
            name="imeKorisnika"
            onChange={(e) =>
              setRegValues({ ...regValues, imeKorisnika: e.target.value })
            }
          ></input>
        </div>
        <div className="form">
          <label>Prezime konobara:</label>
          <input
            type="text"
            name="prezimeKorisnika"
            onChange={(e) =>
              setRegValues({ ...regValues, prezimeKorisnika: e.target.value })
            }
          ></input>
        </div>
        <div className="form">
          <label>Kontakt broj:</label>
          <input
            type="text"
            name="phone"
            onChange={(e) =>
              setRegValues({ ...regValues, kontaktBroj: e.target.value })
            }
            placeholder="npr. 0991234567"
          ></input>
        </div>
        <button className="btn">REGISTRIRAJ</button>
      </form>
      <span className="povratakLogin">
        Povratak na <Link to="/">login</Link>
      </span>

      <div>
        <h3>LISTA KONOBARA</h3>
      </div>
      <div>
        <table className="moja-tablica">
          <thead>
            <tr>
              <th>Ime:</th>
              <th>Prezime:</th>
              <th>Korisničko ime:</th>
              <th>Lozinka:</th>
              <th>Kontakt broj:</th>
              <th></th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {korisnici.map((d, i) => (
              <tr key={i}>
                <td>{d.imeKorisnika}</td>
                <td>{d.prezimeKorisnika}</td>
                <td>{d.username}</td>
                <td>{d.lozinka}</td>
                <td>{d.kontaktBroj}</td>
                <td>
                  <button
                    className="gumb-uredi"
                    onClick={() => {
                      navigate(`/urediKorisnika/${d.id}`);
                    }}
                  >
                    Uredi
                  </button>
                </td>
                <td>
                  <button
                    className="gumb-cancel"
                    onClick={(e) => handleDelete(d.id, d.username)}
                  >
                    Obriši
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Registracija;

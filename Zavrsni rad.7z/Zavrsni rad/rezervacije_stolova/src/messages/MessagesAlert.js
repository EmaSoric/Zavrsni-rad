import React from "react";
import {
  FaCheckCircle,
  FaExclamationTriangle,
  FaInfoCircle,
} from "react-icons/fa";

function MessagesAlert({ poruka, onClose, type = "info" }) {
  let icon;

  if (type === "success") icon = <FaCheckCircle />;
  else if (type === "error") icon = <FaExclamationTriangle />;
  else icon = <FaInfoCircle />;

  return (
    <div className={`poruka ${type}`}>
      {icon}
      <span>{poruka}</span>
      <button onClick={onClose}>X</button>
    </div>
  );
}

export default MessagesAlert;

import React from "react";

function MessageConfirm({ poruka, onClose, type = "confirmation" }) {
  return (
    <div className={`"poruka"${type}`}>
      <span>{poruka}</span>
      <button onClick={onClose}></button>
    </div>
  );
}

export default MessageConfirm;

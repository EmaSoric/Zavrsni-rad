import Login from "./Login";
import Registracija from "./Registracija";
import NavBar from "./NavBar";
import UnosRezervacija from "./UnosRezervacija";
import PregledRezervacija from "./PregledRezervacija";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import UpdateKorisnika from "./UpdateKorisnika";
import UpdateRezervacije from "./UpdateRezervacije";

export default function App() {
  return (
    <>
      <h1 style={{ margin: "30px", textAlign: "center" }}>
        REZERVACIJE STOLOVA
      </h1>

      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />}></Route>
          <Route path="/registracija" element={<Registracija />}></Route>
          <Route
            path="/urediKorisnika/:id"
            element={<UpdateKorisnika />}
          ></Route>
          <Route
            path="/urediRezervaciju/:id"
            element={<UpdateRezervacije />}
          ></Route>
          <Route path="/navbar" element={<NavBar />}>
            <Route
              path="/navbar/unosRezervacija"
              element={<UnosRezervacija />}
            ></Route>
            <Route
              path="/navbar/pregledRezervacija"
              element={<PregledRezervacija />}
            ></Route>
            <Route path="/navbar/login" element={<Login />}></Route>
          </Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

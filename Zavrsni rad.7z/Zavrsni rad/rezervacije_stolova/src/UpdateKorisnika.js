import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

function UpdateKorisnika() {
  const [korValues, setKorValues] = useState({
    username: "",
    lozinka: "",
    prezimeKorisnika: "",
    kontaktBroj: "",
  });
  const navigate = useNavigate();
  const { id } =
    useParams(); /**ovako dohvaćam id parametar, a kada ga šaljem onda samo napišem const id= useParams(); */

  /**dohvaćanje ID korisnika za ispis u formi za azuriranje */
  useEffect(() => {
    axios
      .get("http://localhost:5000/korisnikID/" + id)
      .then((res) => {
        console.log("Primljeni podaci:", res.data);
        setKorValues({
          username: res.data.username,
          lozinka: res.data.lozinka,
          prezimeKorisnika: res.data.prezimeKorisnika,
          kontaktBroj: res.data.kontaktBroj,
        });
      })
      .catch((err) => console.log(err));
  }, [id]);
  const handleSubmit = (e) => {
    e.preventDefault();

    axios
      .put("http://localhost:5000/update/updateKor/" + id, korValues)
      .then((res) => {
        console.log("Podaci su uspješno azurirani.", res.data);
        navigate("/registracija");
      })
      .catch((err) => console.log(err));
  };
  return (
    <div className="update">
      <form className="reg-box" onSubmit={handleSubmit}>
        <div className="form">
          <label>Korisničko ime:</label>
          <input
            type="text"
            name="username"
            value={korValues.username}
            readOnly
          ></input>
          <label>Lozinka:</label>
          <input
            type="password"
            name="lozinka"
            maxLength={4}
            value={korValues.lozinka}
            onChange={(e) =>
              setKorValues({ ...korValues, lozinka: e.target.value })
            }
            placeholder="xxxx"
          ></input>
        </div>
        <div className="form">
          <label>Prezime konobara:</label>
          <input
            type="text"
            name="prezimeKorisnika"
            value={korValues.prezimeKorisnika}
            onChange={(e) =>
              setKorValues({ ...korValues, prezimeKorisnika: e.target.value })
            }
          ></input>
        </div>
        <div className="form">
          <label>Kontakt broj:</label>
          <input
            type="text"
            name="phone"
            value={korValues.kontaktBroj}
            onChange={(e) =>
              setKorValues({ ...korValues, kontaktBroj: e.target.value })
            }
            placeholder="npr. 0991234567"
          ></input>
        </div>
        <button className="btn">AŽURIRAJ</button>
      </form>
    </div>
  );
}

export default UpdateKorisnika;

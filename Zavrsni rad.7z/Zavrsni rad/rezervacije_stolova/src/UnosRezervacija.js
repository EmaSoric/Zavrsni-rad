import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import { CiUser } from "react-icons/ci";
import MessagesAlert from "./messages/MessagesAlert";

function Button({ children, onClick }) {
  return (
    <button className="btn" onClick={onClick}>
      {children}
    </button>
  );
}

function UnosRezervacija() {
  const [alert, setAlert] = useState(null);
  const [rajoni, setRajoni] = useState([]);
  const [aktivniRajon, setAktivniRajon] = useState(null);
  const location = useLocation();
  const { korIme } = location.state || { korIme: "Nepoznat" };

  useEffect(() => {
    axios
      .get("http://localhost:5000/rajoni")
      .then((res) => {
        setRajoni(res.data);
        console.log(res.data);
      })
      .catch((err) => console.log(err));
  }, []);

  function toggleRajon(id_rajona) {
    /**uključi/isključi trenutno aktivni rajon */
    setAktivniRajon((trenutni) => (trenutni === id_rajona ? null : id_rajona));
  }

  return (
    <div>
      <h2>
        Konobar{" "}
        <CiUser
          style={{ marginRight: "6px", fontSize: "25px" }}
          strokeWidth={2}
        />{" "}
        {korIme}
      </h2>
      {alert && (
        <MessagesAlert
          poruka={alert.poruka}
          type={alert.type}
          onClose={() => setAlert(null)}
        />
      )}

      <div>
        {rajoni.map((rajon) => (
          <Button
            key={rajon.id_rajona}
            onClick={() => toggleRajon(rajon.id_rajona)}
          >
            {aktivniRajon === rajon.id_rajona ? "Zatvori" : rajon.nazivRajona}
          </Button>
        ))}
      </div>

      {aktivniRajon && (
        <Rezervacije
          rajon={rajoni.find((r) => r.id_rajona === aktivniRajon)}
          alert={alert}
          setAlert={setAlert}
        />
      )}
    </div>
  );
}

function Rezervacije({ rajon, setAlert }) {
  /**ovdje ćemo spremtii konobare i stolove iz baze */
  const [stolovi, setStolovi] = useState([]);
  const [konobari, setKonobari] = useState([]);
  const [rezValues, setRezValues] = useState({
    /**nazivi varijabli moraju biti isti kao i u mysql */
    imeRezervacije: "",
    datum: "",
    vrijeme: "",
    brOsoba: "",
    posebnaNapomena: "",
    broj_stola: "",
    id_kor: "",
  });

  /**dohvačanje stolova i konobara za prikaz u unosu rezervacije */
  useEffect(() => {
    axios
      .get("http://localhost:5000/res/stolovi")
      .then((res) => {
        setStolovi(res.data);
      })
      .catch((err) => console.log(err));
    axios
      .get("http://localhost:5000/korisnici")
      .then((res) => {
        setKonobari(res.data);
      })
      .catch((err) => console.log(err));
  }, []);

  /**prev-zadnja pohranjena vrijednost koja zaržava stare podatke, a nakon toga ide [name]: value -nova vrijednost */
  const handleChange = (e) => {
    const { name, value } = e.target;

    setRezValues((prev) => ({
      ...prev,
      [name]: ["brOsoba", "broj_stola", "id_kor"].includes(name)
        ? value === ""
          ? ""
          : parseInt(value)
        : value,
    }));
  };

  const navigate = useNavigate();
  /**slanje podataka u backend */
  const handleSubmit = (e) => {
    e.preventDefault();
    const { imeRezervacije, vrijeme, datum, brOsoba, broj_stola, id_kor } =
      rezValues;
    if (
      !imeRezervacije ||
      !datum ||
      !vrijeme ||
      !brOsoba ||
      !broj_stola ||
      !id_kor
    ) {
      setAlert({
        poruka: "Molimo popunite sva polja za unos rezervacije",
        type: "info",
      });
    } else {
      axios
        .post("http://localhost:5000/res/rezervacija", rezValues)
        .then((res) => {
          setAlert({ poruka: "Rezervacija spremljena.", type: "success" });
          console.log(rezValues);
          /**resetiranje forme */
          setRezValues({
            imeRezervacije: "",
            datum: "",
            vrijeme: "",
            brOsoba: "",
            posebnaNapomena: "",
            broj_stola: "",
            id_kor: "",
          });
          navigate("/navbar/pregledRezervacija");
        })
        .catch((err) => console.log(err));
    }
  };

  return (
    <div>
      {/*<img src={rajon.img} alt={rajon.name} />*/}
      <form className="unosRez-box" onSubmit={handleSubmit}>
        <div>
          <label>Ime rezervacije:</label>
          <input
            type="text"
            name="imeRezervacije"
            value={rezValues.imeRezervacije}
            onChange={handleChange}
            placeholder="Naziv rezervacije"
          ></input>
        </div>
        <div>
          <label>Datum rezervacije:</label>
          <input
            type="text"
            name="datum"
            value={rezValues.datum}
            onChange={handleChange}
            placeholder="npr. 10.05.2025."
          />
        </div>
        <div>
          <label>Vrijeme dolaska:</label>
          <input
            type="text"
            name="vrijeme"
            value={rezValues.vrijeme}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Broj osoba:</label>
          <input
            type="number"
            name="brOsoba"
            value={rezValues.brOsoba}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Posebne napomene:</label>
          <textarea
            rows="6"
            name="posebnaNapomena"
            value={rezValues.posebnaNapomena}
            onChange={handleChange}
            placeholder="Napomena"
          />
        </div>
        <div>
          <label>Odaberi stol:</label>
          <select
            name="broj_stola"
            value={rezValues.broj_stola}
            onChange={handleChange}
          >
            <option value="">Odaberi stol:</option>
            {stolovi
              .filter((stol) => stol.id_rajona === rajon.id_rajona)
              .map((stol) => (
                <option key={stol.broj_stola} value={stol.broj_stola}>
                  Stol {stol.broj_stola} (kapacitet: {stol.broj_mjesta})
                </option>
              ))}
          </select>
        </div>
        <div>
          <label>Odaberi konobara:</label>
          <select
            name="id_kor"
            value={rezValues.id_kor}
            onChange={handleChange}
          >
            <option value="">Odaberi konobara:</option>
            {konobari.map((kon) => (
              <option key={kon.id} value={kon.id}>
                Konobar:
                {kon.username}
              </option>
            ))}
          </select>
        </div>
        <button className="btn">Spremi rezervaciju</button>
        <button className="btn-cancel">X</button>
      </form>
    </div>
  );
}

export default UnosRezervacija;

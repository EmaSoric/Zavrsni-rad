/** npm init -y   =ovo kreira json datoteku i onda se mogu
 * instalirati npm i mysql express cors nodemon
 * U package.json file treba dodati tamo gdje je script: 
 * "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1",
    "start": "node server.js", //ovo dodati
    "dev": "nodemon server.js" //ovo dodati
    I onda pokrećemo terminal sa npm run dev
 */
import { adminRouter } from "./Routes/AdminRoute.js";
import { korisnikRouter } from "./Routes/KorisnikRoute.js";
import { regRouter } from "./Routes/RegRoute.js";
import { korisniciRouter } from "./Routes/DohvatiKorRoute.js";
import { deleteRouter } from "./Routes/DeleteRoute.js";
import express from "express";
import cors from "cors";
import mysql from "mysql";
import { rezervacijaRouter } from "./Routes/UnosRezervacija.js";
import { stoloviRouter } from "./Routes/DohvatiStolRoute.js";
import { rajoniRouter } from "./Routes/DohvatiRajon.js";
import { dohvatiRezervacijeRouter } from "./Routes/DohvatiRez.js";
import { deleteRezervationRouter } from "./Routes/DeleteRez.js";
import { updateUserRouter } from "./Routes/UpdateUser.js";
import { korisnikIDRouter } from "./Routes/DohvatiKorisnikID.js";
import { rezervacijaIDRouter } from "./Routes/DohvatiRezID.js";

//import fs from "fs"; /** fs služi za automatiziranje kod dodavanja svih routera u server.js */

const app = express();
app.use(
  cors({
    origin: [
      "http://localhost:3000",
    ] /**ovdje upisujemo port kojeg cors spaja sa backendom*/,
    methods: [
      "GET",
      "POST",
      "PUT",
      "DELETE",
    ] /**metode koje koristimo za slanje podataka */,
    credentials: true,
  })
);
app.use(express.json());
/**Pozivanje vanjskih ruta kreiranih u Routes: */
app.use(
  "/auth",
  adminRouter
); /** ovdje pozivamo rutu AdminRoute.js. prvo ide mjesto url a onda js*/
app.use("/auth", korisnikRouter);
app.use("/auth", regRouter);
app.use("/", korisniciRouter);
app.use("/", rajoniRouter);
app.use("/res", stoloviRouter);
app.use("/res", dohvatiRezervacijeRouter);
app.use("/", korisnikIDRouter);
app.use("/", rezervacijaIDRouter);
app.use("/", deleteRouter);
app.use("/", deleteRezervationRouter);
app.use("/res", rezervacijaRouter);
app.use("/update", updateUserRouter);

/** Spajanje na MYSQL bazu */
const db = mysql.createConnection({
  host: "ucka.veleri.hr",
  user: "esoric",
  password: "11",
  database: "esoric",
});

/**Provjera spajanja na MySql bazu */
db.connect((err) => {
  if (err) {
    console.error("Greška pri spjanju na MySql:", err);
    return;
  }
  console.log("Uspješno ste spojeni na MySql!");
});

/**POKRETANJE SERVERA: */
const port = 5000;
app.listen(port, () => {
  console.log(`Server radi na portu ${port}`);
});

export default db;

import express from "express";
import db from "../server.js";

const router = express.Router();

router.get("/korisnici", (req, res) => {
  const sql = "SELECT * FROM korisnikZ";

  db.query(sql, (err, result) => {
    if (err) {
      console.error("Greška pri dohvaćanju korisnika:", err);
      return res.status(500).json({ Error: "Greška u bazi podataka" });
    }
    return res.status(200).json(result); // šalje sve korisnike klijentu
  });
});

export { router as korisniciRouter };

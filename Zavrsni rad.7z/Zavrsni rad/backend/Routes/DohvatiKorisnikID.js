import express from "express";
import db from "../server.js";

const router = express.Router();

router.get("/korisnikID/:id", (req, res) => {
  const sql = "SELECT * FROM korisnikZ WHERE id=?";
  const id = req.params.id;

  db.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).json({ Error: "Greška u bazi podataka." });
    }
    if (result.lenght === 0)
      return res.status(400).json({ Error: "Korisnik nije pronađen." });
    return res.status(200).json(result[0]); /**Vraća samo jednog korisnika. */
  });
});

export { router as korisnikIDRouter };

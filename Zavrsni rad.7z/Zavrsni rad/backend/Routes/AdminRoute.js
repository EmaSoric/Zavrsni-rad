import express from "express";
import db from "../server.js";

const router = express.Router();

router.post("/login", (req, res) => {
  const sql = "SELECT * FROM adminZ WHERE lozinka =?";
  db.query(sql, [req.body.lozinka], (err, result) => {
    if (err) return res.json({ loginStatus: false, Error: "Query error" });
    if (result.length > 0) {
      /**ako je korisnik pronađen */ const lozinka = result[0].lozinka;
      return res.json({ loginStatus: true });
    } else {
      return res.json({
        loginStatus: false,
        Error: "Pogrešna lozinka!",
      });
    }
  });
});

export { router as adminRouter };

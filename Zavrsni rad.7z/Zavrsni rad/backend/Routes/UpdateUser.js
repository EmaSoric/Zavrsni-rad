import db from "../server.js";
import express from "express";

const router = express.Router();

router.put("/updateKor/:id", (req, res) => {
  const sql =
    "UPDATE korisnikZ SET prezimeKorisnika=?, lozinka=?, kontaktBroj=? WHERE id=?";
  const id = req.params.id;
  const values = [
    req.body.prezimeKorisnika,
    req.body.lozinka,
    req.body.kontaktBroj,
  ];

  db.query(sql, [...values, id], (err, data) => {
    if (err) return res.json(err);
    return res.json("updated");
  });
});

export { router as updateUserRouter };

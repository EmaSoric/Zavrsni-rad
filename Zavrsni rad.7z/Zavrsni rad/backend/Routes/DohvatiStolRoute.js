import express from "express";
import db from "../server.js";

const router = express.Router();

router.get("/stolovi", (req, res) => {
  const sql = "SELECT * FROM stol";

  db.query(sql, (err, result) => {
    if (err) {
      console.error("Greška pri dohvačanju stolova:", err);
      return res.status(500).json({ Error: "Greška u bazi podataka." });
    }
    return res.status(200).json(result); //
  });
});

export { router as stoloviRouter };

import express from "express";
import db from "../server.js";

const router = express.Router();

router.get("/prikazRezervacije", (req, res) => {
  const sql =
    "SELECT r.*, k.username FROM rezervacijeStolova r JOIN korisnikZ k ON r.id_kor =  k.id";

  db.query(sql, (err, result) => {
    if (err) {
      console.error("Greška pri dohvačanju rezervacija.", err);
      return res.status(500).json({ Error: "Greška u bazi podataka." });
    }
    return res.status(200).json(result); //šalje sve rezervacije klijentu
  });
});

export { router as dohvatiRezervacijeRouter };

import db from "../server.js";
import express from "express";

const router = express.Router();

router.delete("/deleteRez/:id", (req, res) => {
  const sql = "DELETE from rezervacijeStolova WHERE id=?";
  const id = req.params.id;

  db.query(sql, [id], (err, data) => {
    if (err) return res.json(err);
    return res.json("Reservation has been deleted.");
  });
});

export { router as deleteRezervationRouter };

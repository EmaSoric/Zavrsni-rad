import express from "express";
import db from "../server.js";

const router = express.Router();

router.post("/registracija", (req, res) => {
  console.log(req.body);
  const { username, lozinka, imeKorisnika, prezimeKorisnika, kontaktBroj } =
    req.body;
  /**Provjera postojećeg korisnika */
  const provjeraKorSql = "SELECT * FROM korisnikZ where username=?";
  db.query(provjeraKorSql, [username], (err, result) => {
    if (err)
      return res.status(500).json({
        regStatus: false,
        Error: "Greška kod provjere korisnika.",
      });
    if (result.length > 0) {
      return res.status(409).json({
        regStatus: false,
        Error: "Uneseno korisničko ime već postoji.",
      });
    } else {
      /**ako korsnik ne postoji onda ga unesi: */
      const sql =
        "INSERT INTO korisnikZ (username, lozinka, imeKorisnika, prezimeKorisnika, kontaktBroj) VALUES (?, ?, ?, ?, ?)";
      db.query(
        sql,
        [username, lozinka, imeKorisnika, prezimeKorisnika, kontaktBroj],
        (err, result) => {
          if (err) return res.json({ status: false, Error: "Query error." });
          res.status(201).json({
            message: "Registracija uspješna",
            userId: result.insertId,
            regStatus: true,
          });
        }
      );
    }
  });
});

export { router as regRouter };

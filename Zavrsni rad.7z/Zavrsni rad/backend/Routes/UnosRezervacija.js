import express from "express";
import db from "../server.js";

const router = express.Router();

router.post("/rezervacija", (req, res) => {
  const {
    imeRezervacije,
    datum,
    vrijeme,
    brOsoba,
    posebnaNapomena,
    broj_stola,
    id_kor,
  } = req.body;

  const sql =
    "INSERT INTO rezervacijeStolova (imeRezervacije, datum, vrijeme, brOsoba, posebnaNapomena, broj_stola, id_kor) VALUES (?,?,?,?,?,?,?) ";
  db.query(
    sql,
    [
      imeRezervacije,
      datum,
      vrijeme,
      brOsoba,
      posebnaNapomena,
      broj_stola,
      id_kor,
    ],
    (err, result) => {
      if (err) return res.json({ status: false, Error: "Query eror!" });
      res.status(201).json({ message: "Rezervacija spremljena." });
    }
  );
});

export { router as rezervacijaRouter };

import express from "express";
import db from "../server.js";

const router = express.Router();

router.post("/korLogin", (req, res) => {
  const { username, lozinka } = req.body;
  const sql = "SELECT * FROM korisnikZ WHERE username = ? AND lozinka = ? ";
  db.query(sql, [username, lozinka], (err, result) => {
    if (err) return res.json({ loginStatus: false, Error: "Query error" });
    if (result.length > 0) {
      return res.json({ loginStatus: true });
    } else {
      return res.json({
        loginStatus: false,
        Error: "Pogrešno korisničko ime ili lozinka!",
      });
      console.log(res);
    }
  });
});

export { router as korisnikRouter };

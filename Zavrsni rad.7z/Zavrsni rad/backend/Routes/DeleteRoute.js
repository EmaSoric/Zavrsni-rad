import db from "../server.js";
import express from "express";

const router = express.Router();

router.delete("/delete/:id", (req, res) => {
  const sql = "DELETE from korisnikZ WHERE id=?";
  const id = req.params.id;

  db.query(sql, [id], (err, data) => {
    if (err) return res.json(err);
    return res.json("deleted");
  });
});

export { router as deleteRouter };
